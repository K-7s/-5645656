# Architecture rules
- Keep Lua encoding in the browser-only-safe `src/lib/obfuscator.ts` module so original source is never transmitted to hosting.
- Store generated outputs in `hosted_scripts` with an `owner_id`; authenticated server functions and RLS must restrict read/write access to that owner.
- Serve hosted code through `/raw/$id` only after validating the caller's Supabase bearer session and matching `owner_id`; never render HTML for successful raw script responses.
- Keep all visual roles and responsive layout styles in `src/styles.css` and use the shared UI controls.
- Parse source locally with luaparse in `src/lib/lua-check.ts` without executing or transmitting it; syntax findings are advisory for Luau because the parser targets standard Lua.
- Track draft changes against the last successful publish; switching workspace tabs must preserve the draft and must not trigger the browser departure warning.
- Do not generate anonymous loadstrings for private scripts: Luau clients cannot use a user's browser session without embedding credentials.

<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->
- Raw endpoints are private and session-authenticated; do not restore client-side signing secrets or public read access.
