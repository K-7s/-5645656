import { createFileRoute, useBlocker } from '@tanstack/react-router';
import { useEffect, useRef, useState, type FormEvent } from 'react';
import { ArrowDownToLine, Code2, FolderCode, LoaderCircle, LogOut, RotateCcw, Search, FileCheck2, Upload } from 'lucide-react';
import type { Session } from '@supabase/supabase-js';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { DEFAULT_SOURCE, obfuscate, type Preset } from '@/lib/obfuscator';
import { checkLuaSyntax, type LuaIssue } from '@/lib/lua-check';
import { filterScripts, hasUnsavedChanges, type Draft } from '@/lib/workspace';
import { listScripts, publishScript, type HostedScript, type HostedScriptSummary } from '@/lib/hosting';

export const Route = createFileRoute('/')({
  head: () => ({ meta: [
    { title: 'NULLSHIFT — تشفير سكربتات Lua واستضافتها' },
    { name: 'description', content: 'مساحة خاصة لسكربتات Lua: شفّر السكربت، واستضف نسخة لا يصل إليها إلا حسابك.' },
    { property: 'og:title', content: 'NULLSHIFT — تشفير سكربتات Lua واستضافتها' },
    { property: 'og:description', content: 'تشفير عشوائي واستضافة خاصة لسكربتات Lua.' },
    { property: 'og:type', content: 'website' },
    { name: 'twitter:card', content: 'summary' },
  ] }), component: AuthGate,
});

type ScriptSummary = HostedScriptSummary;
const PRESET_AR: Record<Preset, string> = { balanced: 'متوازن', hardened: 'قوي', maximum: 'أقصى' };
const formatBytes = (bytes: number) => bytes < 1000 ? `${bytes} B` : `${(bytes / 1000).toFixed(1)} KB`;

function AuthGate() {
  const [session, setSession] = useState<Session | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [authBusy, setAuthBusy] = useState(false);
  const [authError, setAuthError] = useState('');
  const [authMessage, setAuthMessage] = useState('');

  useEffect(() => {
    let active = true;
    void supabase.auth.getSession().then(({ data, error }) => {
      if (!active) return;
      if (error) setAuthError('ما قدرنا نتحقق من جلسة الدخول.');
      setSession(data.session);
      setAuthReady(true);
    }).catch(() => {
      if (!active) return;
      setAuthError('ما قدرنا نتحقق من جلسة الدخول.');
      setAuthReady(true);
    });
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      setSession(nextSession);
      setAuthReady(true);
    });
    return () => {
      active = false;
      subscription.unsubscribe();
    };
  }, []);

  async function submitAuth(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setAuthBusy(true);
    setAuthError('');
    setAuthMessage('');
    try {
      const result = authMode === 'signin'
        ? await supabase.auth.signInWithPassword({ email: email.trim(), password })
        : await supabase.auth.signUp({ email: email.trim(), password });
      if (result.error) throw result.error;
      if (authMode === 'signup' && !result.data.session) {
        setAuthMessage('تم إنشاء الحساب. افحص بريدك لتأكيده، ثم سجّل الدخول.');
      } else {
        setAuthMessage('تم تسجيل الدخول.');
      }
    } catch (error) {
      setAuthError(error instanceof Error ? error.message : 'تعذّر تسجيل الدخول.');
    } finally {
      setAuthBusy(false);
    }
  }

  if (!authReady) {
    return <div className="auth-shell"><div className="panel auth-card" role="status"><LoaderCircle className="size-5 animate-spin" /> جارٍ التحقق من الجلسة…</div></div>;
  }
  if (!session) {
    return <div className="auth-shell">
      <section className="panel auth-card">
        <div className="brand" dir="ltr">NULL<span className="brand-suffix">SHIFT</span></div>
        <h1>{authMode === 'signin' ? 'تسجيل الدخول' : 'إنشاء حساب'}</h1>
        <p className="muted">السكربتات المستضافة خاصة بحسابك ولا تتوفر عبر روابط عامة.</p>
        <form className="auth-form" onSubmit={submitAuth}>
          <label className="field-label" htmlFor="auth-email">البريد الإلكتروني</label>
          <input id="auth-email" className="script-name" type="email" autoComplete="email" required value={email} onChange={event => setEmail(event.target.value)} />
          <label className="field-label" htmlFor="auth-password">كلمة المرور</label>
          <input id="auth-password" className="script-name" type="password" autoComplete={authMode === 'signin' ? 'current-password' : 'new-password'} minLength={6} required value={password} onChange={event => setPassword(event.target.value)} />
          {authError && <div role="alert" className="error-message">{authError}</div>}
          {authMessage && <div role="status" className="auth-message">{authMessage}</div>}
          <Button className="generate-button" type="submit" disabled={authBusy}>
            {authBusy && <LoaderCircle className="animate-spin" />}
            {authBusy ? 'جارٍ التحقق…' : authMode === 'signin' ? 'دخول' : 'إنشاء حساب'}
          </Button>
        </form>
        <Button variant="link" onClick={() => { setAuthMode(authMode === 'signin' ? 'signup' : 'signin'); setAuthError(''); setAuthMessage(''); }}>
          {authMode === 'signin' ? 'ما عندك حساب؟ أنشئ حساباً' : 'عندك حساب؟ سجّل الدخول'}
        </Button>
      </section>
    </div>;
  }

  return <Dashboard
    accessToken={session.access_token}
    email={session.user.email ?? ''}
    onSignOut={() => { void supabase.auth.signOut(); }}
  />;
}

function Dashboard({ accessToken, email, onSignOut }: { accessToken: string; email: string; onSignOut: () => void }) {
  const [view, setView] = useState<'workspace' | 'scripts'>('workspace');
  const [source, setSource] = useState(DEFAULT_SOURCE);
  const [name, setName] = useState('untitled.lua');
  const [preset, setPreset] = useState<Preset>('hardened');
  const [integrity, setIntegrity] = useState(true);
  const [decoys, setDecoys] = useState(true);
  const [result, setResult] = useState<ReturnType<typeof obfuscate> | null>(null);
  const [hosted, setHosted] = useState<HostedScript | null>(null);
  const [scripts, setScripts] = useState<ScriptSummary[]>([]);
  const [busy, setBusy] = useState(false);
  const [loadingScripts, setLoadingScripts] = useState(false);
  const [outputMode, setOutputMode] = useState(false);
  const [error, setError] = useState('');
  const [query, setQuery] = useState('');
  const [syntax, setSyntax] = useState<LuaIssue | 'valid' | null>(null);
  const [saved, setSaved] = useState<Draft>({ source: DEFAULT_SOURCE, name: 'untitled.lua', preset: 'hardened', integrity: true, decoys: true });
  const draft = { source, name, preset, integrity, decoys };
  const isDirty = hasUnsavedChanges(draft, saved);
  useBlocker({ shouldBlockFn: () => false, enableBeforeUnload: isDirty });
  useEffect(() => { setSyntax(null); }, [source]);
  const filteredScripts = filterScripts(scripts, query);
  const fileInput = useRef<HTMLInputElement>(null);
  const sourceBytes = new TextEncoder().encode(source).length;

  function validateSyntax() {
    const issue = checkLuaSyntax(source);
    setSyntax(issue ?? 'valid');
    return issue;
  }
  async function generate(skipSyntax = false) {
    if (!skipSyntax && validateSyntax()) return;
    const publishedDraft = { source, name, preset, integrity, decoys };
    setError(''); setBusy(true); setHosted(null);
    try {
      if (!name.trim()) throw new Error('اكتب اسم للسكربت أول.');
      await new Promise(resolve => setTimeout(resolve, 350));
      const generated = obfuscate(source, { preset, integrity, decoys });
      setResult(generated);
      const record = await publishScript(name.trim(), generated.code, generated.sourceBytes, preset);
      setSaved(publishedDraft); setHosted(record); setScripts(previous => [record, ...previous.filter(s => s.id !== record.id)]);
      toast.success('تمت الحماية والاستضافة الخاصة بحسابك.');
    } catch (e) { setError(e instanceof Error ? e.message : 'ما قدرنا نحمي هالسكربت.'); }
    finally { setBusy(false); }
  }
  async function openScripts() {
    setView('scripts'); setLoadingScripts(true); setError('');
    try { setScripts(await listScripts()); } catch (e) { setError(e instanceof Error ? e.message : 'ما قدرنا نحمّل السكربتات.'); }
    finally { setLoadingScripts(false); }
  }
  function download() {
    if (!result) return;
    const url = URL.createObjectURL(new Blob([result.code], { type: 'text/plain' }));
    const anchor = document.createElement('a'); anchor.href = url; anchor.download = name.replace(/\.lua$/i, '') + '.protected.lua'; anchor.click(); URL.revokeObjectURL(url);
  }
  async function downloadHostedScript(script: ScriptSummary) {
    try {
      const response = await fetch(`/raw/${script.id}`, { headers: { Authorization: `Bearer ${accessToken}` } });
      if (!response.ok) throw new Error(response.status === 401 ? 'انتهت جلسة الدخول. سجّل الدخول مرة ثانية.' : 'ما قدرنا ننزّل السكربت الخاص.');
      const code = await response.text();
      const url = URL.createObjectURL(new Blob([code], { type: 'text/plain' }));
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.download = script.name.replace(/\.lua$/i, '') + '.protected.lua';
      anchor.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'ما قدرنا ننزّل السكربت الخاص.');
    }
  }
  function canReplaceDraft() { return !isDirty || window.confirm('عندك تعديلات لسه ما استضفتها. بدك تستبدلها؟'); }
  function resetWorkspace() { if (!canReplaceDraft()) return; setSource(DEFAULT_SOURCE); setName('untitled.lua'); setResult(null); setHosted(null); setError(''); setOutputMode(false); setSyntax(null); }
  async function uploadFile(file: File) {
    if (file.size > 100000) { toast.error('اختار سكربت أصغر من 100 كيلوبايت.'); return; }
    if (!canReplaceDraft()) return;
    try {
      const text = await file.text();
      setSource(text); setName(file.name.slice(0, 100)); setOutputMode(false); setResult(null); setHosted(null); setError('');
      toast.success('انحمّل السكربت بالمحرر.');
    } catch { toast.error('ما قدرنا نقرأ الملف. جرّب ترفعه مرة ثانية.'); }
  }

  return <div className="app-shell">
    <header className="topbar">
      <div className="brand" dir="ltr">NULL<span className="brand-suffix">SHIFT</span></div>
      <nav className="tabs" aria-label="التنقل الرئيسي">
        <button className={`tab ${view === 'workspace' ? 'active' : ''}`} onClick={() => setView('workspace')}>التشفير</button>
        <button className={`tab ${view === 'scripts' ? 'active' : ''}`} onClick={openScripts}>سكربتاتي المستضافة</button>
      </nav>
      <div className="account-bar">
        <span dir="ltr">{email}</span>
        <Button variant="ghost" size="sm" onClick={onSignOut}><LogOut className="size-4" /> خروج</Button>
      </div>
    </header>
    <main className="content">
      {view === 'workspace' ? <>
        <div className="workspace-grid">
          <section className="panel editor-panel" aria-label="محرر السكربت">
            <div className="panel-toolbar">
              <div className="editor-tabs">
                <button dir="ltr" className={`editor-mode ${!outputMode ? 'selected' : ''}`} onClick={() => setOutputMode(false)}>{name}</button>
                {result && <button className={`editor-mode ${outputMode ? 'selected' : ''}`} onClick={() => setOutputMode(true)}>النتيجة</button>}
              </div>
              <div className="toolbar-actions" dir="ltr">
                <Button variant="ghost" size="icon" title="فحص صياغة Lua" aria-label="فحص صياغة Lua" disabled={busy || !source.trim()} onClick={validateSyntax}><FileCheck2 className="size-4" /></Button>
                <Button variant="ghost" size="icon" title="رفع سكربت Lua" aria-label="رفع سكربت Lua" onClick={() => fileInput.current?.click()}><Upload className="size-4" /></Button>
                <Button variant="ghost" size="icon" title="إعادة ضبط المحرر" aria-label="إعادة ضبط المحرر" onClick={resetWorkspace}><RotateCcw className="size-4" /></Button>
              </div>
            </div>
            <textarea aria-label={outputMode ? 'الكود المشفّر' : 'كود Lua'} dir="ltr" className="source-editor" value={outputMode ? result?.code ?? '' : source} onChange={e => setSource(e.target.value)} readOnly={outputMode} spellCheck={false} wrap="off" onKeyDown={e => {if(e.key==='Tab' && !outputMode){e.preventDefault();const el=e.currentTarget;const start=el.selectionStart;const end=el.selectionEnd;setSource(source.slice(0,start)+'    '+source.slice(end));requestAnimationFrame(()=>{el.selectionStart=el.selectionEnd=start+4;});}}} />
            {syntax && <div className={`syntax-status ${syntax === 'valid' ? 'syntax-valid' : 'syntax-warning'}`} role="status">{syntax === 'valid' ? <span>صياغة Lua سليمة.</span> : <><span>راجع السطر {syntax.line}: <bdi dir="ltr">{syntax.message}</bdi></span><small>الفحص لـ Lua 5.3؛ إضافات Luau ممكن تعطي تنبيه حتى لو الكود سليم.</small><Button variant="link" size="sm" disabled={busy} onClick={() => generate(true)}>استضف رغم التنبيه</Button></>}</div>}
            <div className="editor-footer"><span>{outputMode ? 'الكود المشفّر' : 'السكربت الأصلي'}</span><span>{source.split('\n').length} سطر · {formatBytes(sourceBytes)}{result && ` · الناتج ${formatBytes(result.outputBytes)}`}</span></div>
          </section>
          <section className="panel config-panel" aria-label="إعدادات الحماية">
            <div>
              <label className="field-label" htmlFor="script-name">اسم السكربت</label>
              <input id="script-name" dir="ltr" className="script-name" maxLength={100} value={name} onChange={e=>setName(e.target.value)} />
            </div>
            <div>
              <span className="field-label">مستوى الحماية</span>
              <div className="preset-group">{(['balanced','hardened','maximum'] as const).map(p=><Button key={p} variant={preset===p ? 'default':'secondary'} aria-pressed={preset===p} onClick={()=>setPreset(p)}>{PRESET_AR[p]}</Button>)}</div>
            </div>
            <div className="option-row"><label htmlFor="integrity" className="option-copy">حارس السلامة<small>يكشف أي تعديل على الكود</small></label><Switch dir="ltr" id="integrity" checked={integrity} onCheckedChange={setIntegrity} /></div>
            <div className="option-row"><label htmlFor="decoys" className="option-copy">كود وهمي<small>فروع عشوائية بدون فايدة</small></label><Switch dir="ltr" id="decoys" checked={decoys} onCheckedChange={setDecoys} /></div>
            <Button className="generate-button desktop-only" onClick={() => generate()} disabled={busy || !source.trim()}>{busy && <LoaderCircle className="animate-spin" />}{busy ? 'جاري العمل…' : 'شفّر واستضف'}</Button>
            <p className="generation-note">السكربت الأصلي ما بيطلع من متصفحك.</p>
          </section>
        </div>
        {error && <div role="alert" className="error-message">{error}</div>}
        <section className="panel loadstring-section">
          <h2>الوصول الخاص</h2>
          <div className="loadstring-box">
            <span>النسخة المستضافة لا تملك رابطاً عاماً أو loadstring مجهولاً.</span>
            {result && <Button variant="default" size="sm" onClick={download}><ArrowDownToLine className="size-4" /> تنزيل النسخة</Button>}
          </div>
          {hosted && <p className="muted">تم حفظ الناتج في حسابك. يمكنك تنزيله من قائمة السكربتات بعد تسجيل الدخول.</p>}
        </section>
      </> : <section className="library">
        <div className="library-head"><h2>سكربتاتي المستضافة</h2><Button variant="outline" size="sm" onClick={()=>setView('workspace')}>سكربت جديد</Button></div>
        <p className="muted">الكود الناتج خاص بحسابك. السكربت الأصلي عمره ما بينرفع.</p>
        <label className="library-search"><Search className="size-4" /><input type="search" aria-label="البحث باسم السكربت" placeholder="ابحث باسم السكربت…" value={query} onChange={e => setQuery(e.target.value)} /></label>
        {loadingScripts ? <div className="empty-state"><LoaderCircle className="size-5 animate-spin mx-auto" /></div> : !scripts.length ? <div className="empty-state"><p>ما في سكربتات مستضافة لسه.</p><Button className="mt-4" onClick={()=>setView('workspace')}>سوّي أول سكربت</Button></div> : !filteredScripts.length ? <div className="empty-state"><p>ما لقينا سكربت بهالاسم.</p><Button variant="ghost" onClick={() => setQuery('')}>مسح البحث</Button></div> : filteredScripts.map(script=><div className="library-row" key={script.id}><div className="script-details"><h3 dir="ltr" className="text-start">{script.name}</h3><p>{PRESET_AR[script.preset as Preset] ?? script.preset} · {formatBytes(script.source_bytes)} · {new Date(script.created_at).toLocaleDateString('ar')}</p></div><Button variant="outline" size="sm" onClick={()=>void downloadHostedScript(script)}><ArrowDownToLine className="size-4" /> تنزيل</Button></div>)}
        {error && <div role="alert" className="error-message">{error}</div>}
      </section>}
    </main>
    {view === 'workspace' && <div className="mobile-generate"><Button className="generate-button" onClick={() => generate()} disabled={busy || !source.trim()}>{busy && <LoaderCircle className="animate-spin" />}{busy ? 'جاري العمل…' : 'شفّر واستضف'}</Button></div>}
    <nav className="bottom-nav" aria-label="التنقل السفلي">
      <button className={view === 'workspace' ? 'active' : ''} onClick={() => setView('workspace')}><Code2 />التشفير</button>
      <button className={view === 'scripts' ? 'active' : ''} onClick={openScripts}><FolderCode />سكربتاتي</button>
    </nav>
    <input ref={fileInput} type="file" accept=".lua,.luau,.txt" hidden onChange={e => { const file = e.target.files?.[0]; e.target.value = ''; if (file) void uploadFile(file); }} />
  </div>;
}
