import { createFileRoute } from '@tanstack/react-router';
import { serveRaw } from '@/lib/raw-handler';
export const Route = createFileRoute('/raw/$id')({
  server: { handlers: { GET: async ({ params, request }) => serveRaw(params.id, request) } },
});
