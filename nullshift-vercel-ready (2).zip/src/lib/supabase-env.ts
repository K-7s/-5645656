// Reads backend settings at request time. Works on Lovable (SUPABASE_*) and on
// other hosts such as Vercel. Falls back to the public (publishable) backend
// address so hosting keeps working even if host env vars are missing.
const PUBLIC_URL = 'https://c--fb4a75e1-aaa0-461d-a99c-cc243f73b519-prod.lovable.cloud';
const PUBLIC_KEY = 'sb_publishable_cTxK79K_Le09f45yemEYTQ_-w4O3yOZ';
export function backendEnv(): { url: string | undefined; key: string | undefined } {
  const e = process.env;
  return {
    url: e['SUPABASE_URL'] || e['VITE_SUPABASE_URL'] || PUBLIC_URL,
    key: e['SUPABASE_PUBLISHABLE_KEY'] || e['VITE_SUPABASE_PUBLISHABLE_KEY'] || PUBLIC_KEY,
  };
}
