// Rotating link tokens: every second the loader builds a different URL (?t=time&k=signature).
// The server only accepts a link for a short window, so a copied raw URL stops working quickly.
// Pure arithmetic (no Node/browser APIs) so it runs in the browser, on the server and inside Lua.
const PEPPER = 'nullshift-rotating-link-v1';
const MOD = 4294967291;
export const LINK_WINDOW_SECONDS = 30;

export function makeToken(id: string, t: number): string {
  const text = `${id}:${t}:${PEPPER}`;
  let h = 5381;
  for (let i = 0; i < text.length; i++) h = (h * 33 + (text.charCodeAt(i) & 255)) % MOD;
  return String(h);
}

export function verifyToken(id: string, t: string | null, k: string | null, nowSeconds = Math.floor(Date.now() / 1000)): boolean {
  if (!t || !k || !/^\d{9,12}$/.test(t) || !/^\d{1,10}$/.test(k)) return false;
  const stamp = Number(t);
  if (Math.abs(nowSeconds - stamp) > LINK_WINDOW_SECONDS) return false;
  return makeToken(id, stamp) === k;
}

export function signedRawUrl(url: string, nowSeconds = Math.floor(Date.now() / 1000)): string {
  const id = url.split('/').pop() ?? '';
  return `${url}?t=${nowSeconds}&k=${makeToken(id, nowSeconds)}`;
}

// Lua helper that mirrors makeToken exactly (works on Lua 5.1 – 5.4 and Roblox executors).
export function luaTokenSnippet(id: string): string {
  return `local function stamp() return (os and os.time and os.time()) or math.floor(tick()) end; local function sign(t) local s = ${JSON.stringify(id)} .. ":" .. t .. ":${PEPPER}"; local h = 5381; for i = 1, #s do h = (h * 33 + s:byte(i)) % ${MOD} end; return string.format("%.0f", h) end`;
}
