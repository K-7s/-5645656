import { describe, expect, it } from 'vitest';
import { checkLuaSyntax } from './lua-check';
import { filterScripts, hasUnsavedChanges } from './workspace';

describe('Lua syntax check', () => {
  it('accepts valid Lua without executing it', () => {
    expect(checkLuaSyntax('while true do end')).toBeNull();
    expect(checkLuaSyntax('local message = "مرحبا"\nreturn message')).toBeNull();
  });
  it('reports the actual error line before encoding', () => {
    expect(checkLuaSyntax('local x = 1\nlocal y = )')?.line).toBe(2);
  });
  it('rejects incomplete blocks', () => {
    expect(checkLuaSyntax('if true then\nprint("hello")')).not.toBeNull();
  });
});

describe('Workspace helpers', () => {
  const saved = { source: 'return 1', name: 'a.lua', preset: 'hardened', integrity: true, decoys: true };
  it('warns for source changes and clears for the successfully hosted draft', () => {
    const edited = { ...saved, source: 'return 2' };
    expect(hasUnsavedChanges(edited, saved)).toBe(true);
    expect(hasUnsavedChanges(edited, edited)).toBe(false);
  });
  it('detects name and protection changes', () => {
    expect(hasUnsavedChanges({ ...saved, name: 'b.lua' }, saved)).toBe(true);
    expect(hasUnsavedChanges({ ...saved, decoys: false }, saved)).toBe(true);
  });
  it('searches file names ignoring case and surrounding spaces', () => {
    const scripts = [{ name: 'Hello.lua' }, { name: 'آخر.lua' }];
    expect(filterScripts(scripts, ' HELLO ')).toEqual([scripts[0]]);
    expect(filterScripts(scripts, 'آخر')).toEqual([scripts[1]]);
    expect(filterScripts(scripts, 'absent')).toEqual([]);
    expect(filterScripts(scripts, '')).toEqual(scripts);
  });
});
