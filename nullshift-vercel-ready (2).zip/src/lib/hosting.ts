import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';
import type { Preset } from './obfuscator';
export type HostedScript = {
 id: string;
 name: string;
 code: string;
 source_bytes: number;
 preset: string;
 created_at: string;
 owner_id: string | null;
};
export type HostedScriptSummary = Omit<HostedScript, 'code'>;

const publish = createServerFn({ method: 'POST' })
 .middleware([requireSupabaseAuth])
 .inputValidator(z.object({
  name: z.string().trim().min(1).max(100),
  code: z.string().min(1).max(2000000),
  source_bytes: z.number().int().min(1).max(100000),
  preset: z.enum(['balanced', 'hardened', 'maximum']),
 }))
 .handler(async ({ data, context }) => {
  const { data: record, error } = await context.supabase
   .from('hosted_scripts')
   .insert({ ...data, owner_id: context.userId })
   .select()
   .single();
  if (error) throw new Error('الاستضافة غير متاحة مؤقتاً. لسه تقدر تنزّل الكود الجاهز.');
  return record;
 });

const list = createServerFn({ method: 'GET' })
 .middleware([requireSupabaseAuth])
 .handler(async ({ context }) => {
  const { data, error } = await context.supabase
   .from('hosted_scripts')
   .select('id,name,source_bytes,preset,created_at,owner_id')
   .eq('owner_id', context.userId)
   .order('created_at', { ascending: false })
   .limit(50);
  if (error) throw new Error('ما قدرنا نحمّل السكربتات. جرّب مرة ثانية.');
  return data;
 });

export async function publishScript(name: string, code: string, sourceBytes: number, preset: Preset) {
 return publish({ data: { name, code, source_bytes: sourceBytes, preset } });
}
export async function listScripts() {
 return list();
}
