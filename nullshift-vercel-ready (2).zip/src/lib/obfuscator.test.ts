import { describe, expect, it } from 'vitest';
// Fengari is a test-only Lua VM; generated code runs unchanged in the interpreter.
// @ts-expect-error fengari does not publish TypeScript declarations
import { lua, lauxlib, lualib, to_luastring, to_jsstring } from 'fengari';
import { obfuscate, loadstringFor, type Preset } from './obfuscator';
import { makeToken, signedRawUrl, verifyToken } from './link-token';
function run(code: string) {
 const state = lauxlib.luaL_newstate(); lualib.luaL_openlibs(state);
 const status = lauxlib.luaL_dostring(state, to_luastring(code));
 if (status !== lua.LUA_OK) throw new Error(to_jsstring(lua.lua_tostring(state, -1)));
 const result = lua.lua_tonumber(state, -1); lua.lua_close(state); return result;
}
describe('Lua obfuscation', () => {
 for (const preset of ['balanced','hardened','maximum'] as Preset[]) {
  it(`preserves execution with ${preset} encoding and decoys`, () => {
   const result = obfuscate('local secret = 21; return secret * 2', {preset, decoys:true, integrity:true});
   expect(result.code).not.toContain('local secret');
   expect(run(result.code)).toBe(42);
  });
 }
 it('preserves unicode and multiline source', () => {
  const result = obfuscate('local value = "مرحبا 🌍"\nreturn #value', {preset:'hardened',decoys:false,integrity:true});
  expect(run(result.code)).toBe(new TextEncoder().encode('مرحبا 🌍').length);
 });
 it('generates randomized output for the same source', () => {
  expect(obfuscate('return 1',{preset:'balanced',decoys:false,integrity:false}).code).not.toBe(obfuscate('return 1',{preset:'balanced',decoys:false,integrity:false}).code);
 });
 it('detects a modified payload before execution', () => {
  const result = obfuscate('return 42',{preset:'balanced',decoys:false,integrity:true});
  const tampered = result.code.replace(/= \{(\d+),/, (_, n:string)=>`= {${Number(n)+1},`);
  expect(()=>run(tampered)).toThrow('integrity check failed');
 });
 it('rejects empty input',()=>expect(()=>obfuscate(' ',{preset:'balanced',decoys:false,integrity:false})).toThrow());
 it('executes a hosted script and preserves its return value', () => {
  expect(run(`game = { HttpGet = function(self, url) local t, k = url:match("^https://example.com/raw/sc%-739b%?t=(%d+)&k=(%d+)$"); assert(t and k); _G.seen = {t, k}; return "return 42" end }; loadstring = load; ${loadstringFor('https://example.com/raw/sc-739b')}`)).toBe(42);
 });
 it('signs the hosted URL with a token the server accepts and rotates by time', () => {
  const t = 1760000000; const url = signedRawUrl('https://example.com/raw/sc-739b', t);
  expect(url).toBe(`https://example.com/raw/sc-739b?t=${t}&k=${makeToken('sc-739b', t)}`);
  expect(verifyToken('sc-739b', String(t), makeToken('sc-739b', t), t + 30)).toBe(true);
  expect(verifyToken('sc-739b', String(t), makeToken('sc-739b', t), t + 31)).toBe(false);
  expect(verifyToken('sc-739b', String(t), makeToken('other', t), t)).toBe(false);
  expect(makeToken('sc-739b', t)).not.toBe(makeToken('sc-739b', t + 1));
 });
 it('Lua loader produces the same token as the server for the same second', () => {
  const t = 1760000123;
  const lua = `os.time = function() return ${t} end; loadstring = load; game = { HttpGet = function(self, url) return "return " .. (url:match("k=(%d+)$") == "${makeToken('sc-739b', t)}" and 1 or 0) end }; ${loadstringFor('https://example.com/raw/sc-739b')}`;
  expect(run(lua)).toBe(1);
 });
 it('reports an unavailable loadstring instead of calling nil', () => {
  expect(() => run(`loadstring = nil; ${loadstringFor('https://example.com/raw/id')}`)).toThrow('NULLSHIFT: loadstring is unavailable');
 });
 it('reports invalid hosted output before attempting execution', () => {
  expect(() => run(`loadstring = load; game = { HttpGet = function() return "<html>Sign in</html>" end }; ${loadstringFor('https://example.com/raw/id')}`)).toThrow('NULLSHIFT: hosted script could not be compiled');
 });
 it('keeps the caller environment when the runtime supports setfenv', () => {
  const generated = obfuscate('return executorOnly()', {preset:'balanced',decoys:false,integrity:true});
  // Model Lua 5.1 executor environment inheritance using Lua 5.3 upvalues.
  const setup = `
local compile = load
local caller = setmetatable({ executorOnly = function() return 73 end }, { __index = _G })
getfenv = function() return caller end
loadstring = function(source) return compile(source, "decoded", "t", {}) end
setfenv = function(fn, env)
 for i = 1, 100 do
  local name = debug.getupvalue(fn, i)
  if not name then break end
  if name == "_ENV" then debug.setupvalue(fn, i, env); break end
 end
 return fn
end
`;
  expect(run(setup + generated.code)).toBe(73);
 });
});
