import { luaTokenSnippet } from './link-token';
export type Preset = 'balanced' | 'hardened' | 'maximum';
export type ProtectionOptions = { preset: Preset; decoys: boolean; integrity: boolean };
export const DEFAULT_SOURCE = `-- Your next script starts here.
local Players = game:GetService("Players")
local player = Players.LocalPlayer

local function initialize()
    print("Connected to " .. player.Name)
    print("Your script. Your rules.")
end

initialize()`;

function randomInt(max: number) {
  const bytes = new Uint32Array(1);
  crypto.getRandomValues(bytes);
  return (bytes[0] ?? 0) % max;
}
function identifier() {
  return '_0x' + Array.from({ length: 8 }, () => randomInt(65536).toString(16).padStart(4, '0')).join('');
}
export function obfuscate(source: string, options: ProtectionOptions) {
  const bytes = new TextEncoder().encode(source);
  if (!source.trim()) throw new Error('ضيف سكربت Lua قبل الحماية.');
  if (bytes.length > 100000) throw new Error('حجم السكربت لازم يكون 100 كيلوبايت أو أقل.');
  const key = 31 + randomInt(180);
  const rounds = { balanced: 1, hardened: 3, maximum: 5 }[options.preset];
  const payload = identifier(), output = identifier(), counter = identifier(), value = identifier(), loader = identifier();
  const encoded = Array.from(bytes, (byte, index) => (byte + key * rounds + ((index + 1) % 251)) % 256);
  const checksum = bytes.reduce((sum, byte) => (sum + byte) % 65521, 0);
  const lines = ['-- Protected with NULLSHIFT | Lua 5.1 / Luau', 'return (function(...)'];
  if (options.decoys) {
    const count = { balanced: 128, hardened: 768, maximum: 2048 }[options.preset];
    lines.push('if false then');
    for (let i = 0; i < count; i++) {
      const name = identifier();
      lines.push(`do local ${name} = {${randomInt(999999)}, "https://decoy-${randomInt(99999999)}.invalid/${randomInt(999999)}"} end`);
    }
    lines.push('end');
  }
  lines.push(`local ${payload} = {${encoded.join(',')}}`, `local ${output} = {}`, `local ${value} = 0`, `for ${counter} = 1, #${payload} do`, `local b = (${payload}[${counter}] - ${key * rounds} - (${counter} % 251)) % 256`, `${output}[${counter}] = string.char(b)`, `${value} = (${value} + b) % 65521`, 'end');
  if (options.integrity) lines.push(`if ${value} ~= ${checksum} then error("NULLSHIFT: integrity check failed", 0) end`);
  lines.push(`local ${loader} = type(loadstring) == "function" and loadstring or load`, `if type(${loader}) ~= "function" then error("NULLSHIFT: loadstring is unavailable", 0) end`, `local f, err = ${loader}(table.concat(${output}), "@NULLSHIFT/source")`, 'if type(f) ~= "function" then error("NULLSHIFT: decoded script could not be compiled: " .. tostring(err), 0) end', 'if type(setfenv) == "function" and type(getfenv) == "function" then setfenv(f, getfenv(1)) end', 'return f(...)', 'end)(...)');
  return { code: lines.join('\n'), sourceBytes: bytes.length, outputBytes: new TextEncoder().encode(lines.join('\n')).length, checksum, layers: rounds };
}
export function loadstringFor(url: string) {
  const id = url.split('/').pop() ?? '';
  return `return (function(...) ${luaTokenSnippet(id)}; local compile = loadstring; if type(compile) ~= "function" then error("NULLSHIFT: loadstring is unavailable in this runtime", 0) end; local ok, source = pcall(function() local t = stamp(); return game:HttpGet(${JSON.stringify(url)} .. "?t=" .. t .. "&k=" .. sign(t)) end); if not ok then error("NULLSHIFT: could not fetch hosted script: " .. tostring(source), 0) end; if type(source) ~= "string" or source == "" then error("NULLSHIFT: hosted response is empty or invalid", 0) end; local fn, err = compile(source, "@NULLSHIFT/hosted"); if type(fn) ~= "function" then error("NULLSHIFT: hosted script could not be compiled: " .. tostring(err), 0) end; if type(setfenv) == "function" and type(getfenv) == "function" then setfenv(fn, getfenv(1)) end; return fn(...) end)(...)`;
}
