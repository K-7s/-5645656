import { parse } from 'luaparse';

export type LuaIssue = { line: number; message: string };

/** Advisory syntax check that runs entirely in the browser. Returns null when the source parses. */
export function checkLuaSyntax(source: string): LuaIssue | null {
  if (!source.trim()) return null;
  try {
    parse(source, { luaVersion: '5.3', comments: false, scope: false, locations: false });
    return null;
  } catch (e) {
    const err = e as { line?: number; message?: string };
    const raw = (err.message ?? 'syntax error').replace(/^\[\d+:\d+\]\s*/, '');
    return { line: err.line ?? 1, message: raw };
  }
}
