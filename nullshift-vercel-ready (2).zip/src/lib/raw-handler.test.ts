import { describe, it, expect } from 'vitest';
import { serveRaw } from './raw-handler';
describe('Raw hosting',()=>{
 it('rejects invalid script identifiers as plaintext', async()=>{
  const response=await serveRaw('../missing', new Request('https://example.com/raw/../missing'));
  expect(response.status).toBe(404);
  expect(response.headers.get('content-type')).toBe('text/plain; charset=utf-8');
  expect(await response.text()).toBe('Script not found');
 });
 it('requires an authenticated bearer token, even when legacy link parameters are present', async()=>{
  const id='a0d4d8a5-5983-473f-ba7a-2f864eec625f';
  const none=await serveRaw(id, new Request(`https://example.com/raw/${id}`));
  expect(none.status).toBe(401);
  const legacy=await serveRaw(id, new Request(`https://example.com/raw/${id}?t=1760000000&k=123`));
  expect(legacy.status).toBe(401);
  const malformed=await serveRaw(id, new Request(`https://example.com/raw/${id}`, {
   headers: { Authorization: 'Bearer not-a-jwt' },
  }));
  expect(malformed.status).toBe(401);
 });
});
