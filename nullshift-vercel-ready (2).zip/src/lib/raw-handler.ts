import { createClient } from '@supabase/supabase-js';
import type { Database } from '@/integrations/supabase/types';
import { backendEnv } from './supabase-env';

export async function serveRaw(id: string, request: Request) {
  const headers = {
    'Content-Type': 'text/plain; charset=utf-8',
    'X-Content-Type-Options': 'nosniff',
    'Cache-Control': 'private, no-store',
    Vary: 'Authorization',
  };
  if (!/^[0-9a-f-]{36}$/i.test(id)) return new Response('Script not found', { status: 404, headers });

  const authorization = request.headers.get('authorization');
  const bearer = authorization?.match(/^Bearer\s+([^\s]+)$/i)?.[1];
  if (!bearer || bearer.split('.').length !== 3) {
    return new Response('Authentication required', { status: 401, headers });
  }

  const { url, key } = backendEnv();
  if (!key || !url) return new Response('Hosting temporarily unavailable', { status: 503, headers });

  const client = createClient<Database>(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: {
      headers: { Authorization: `Bearer ${bearer}` },
      fetch: (input, init) => {
        const h = new Headers(init?.headers);
        if (key.startsWith('sb_') && h.get('Authorization') === `Bearer ${key}`) h.delete('Authorization');
        h.set('apikey', key);
        return fetch(input, { ...init, headers: h });
      },
    },
  });

  let userId: string | undefined;
  try {
    const { data: authData, error: authError } = await client.auth.getClaims(bearer);
    const subject = authData?.claims?.sub;
    if (!authError && typeof subject === 'string') userId = subject;
  } catch {
    return new Response('Authentication required', { status: 401, headers });
  }
  if (!userId) {
    return new Response('Authentication required', { status: 401, headers });
  }

  const { data, error } = await client
    .from('hosted_scripts')
    .select('code')
    .eq('id', id)
    .eq('owner_id', userId)
    .maybeSingle();
  if (error) return new Response('Hosting temporarily unavailable', { status: 503, headers });
  return new Response(data?.code ?? 'Script not found', { status: data ? 200 : 404, headers });
}
