export type Draft = { source: string; name: string; preset: string; integrity: boolean; decoys: boolean };
export function hasUnsavedChanges(current: Draft, saved: Draft): boolean {
  return current.source !== saved.source || current.name !== saved.name || current.preset !== saved.preset || current.integrity !== saved.integrity || current.decoys !== saved.decoys;
}
export function filterScripts<T extends { name: string }>(scripts: T[], query: string): T[] {
  const term = query.trim().toLocaleLowerCase();
  return scripts.filter(script => script.name.toLocaleLowerCase().includes(term));
}
