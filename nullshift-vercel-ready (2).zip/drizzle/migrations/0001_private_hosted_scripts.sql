-- Require authenticated ownership for all newly published scripts.
-- Existing public rows remain in place with owner_id NULL and become inaccessible
-- through the application until an administrator assigns them an owner.
ALTER TABLE public.hosted_scripts
  ADD COLUMN owner_id uuid REFERENCES auth.users(id) ON DELETE CASCADE;

ALTER TABLE public.hosted_scripts
  ADD CONSTRAINT hosted_scripts_owner_required
  CHECK (owner_id IS NOT NULL) NOT VALID;

DROP POLICY IF EXISTS "Public generated output is readable" ON public.hosted_scripts;
DROP POLICY IF EXISTS "Open access immutable script publishing" ON public.hosted_scripts;

REVOKE ALL ON public.hosted_scripts FROM anon;
GRANT SELECT, INSERT ON public.hosted_scripts TO authenticated;

CREATE POLICY "Users can read their own hosted scripts"
  ON public.hosted_scripts
  FOR SELECT
  TO authenticated
  USING ((SELECT auth.uid()) = owner_id);

CREATE POLICY "Users can publish their own hosted scripts"
  ON public.hosted_scripts
  FOR INSERT
  TO authenticated
  WITH CHECK ((SELECT auth.uid()) = owner_id);
