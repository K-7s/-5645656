CREATE TABLE public.hosted_scripts (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 name text NOT NULL CHECK (char_length(name) BETWEEN 1 AND 100),
 code text NOT NULL CHECK (octet_length(code) BETWEEN 1 AND 2000000),
 source_bytes integer NOT NULL DEFAULT 0,
 preset text NOT NULL DEFAULT 'balanced' CHECK (preset IN ('balanced','hardened','maximum')),
 created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.hosted_scripts TO anon, authenticated;
GRANT ALL ON public.hosted_scripts TO service_role;
ALTER TABLE public.hosted_scripts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public generated output is readable" ON public.hosted_scripts FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Open access immutable script publishing" ON public.hosted_scripts FOR INSERT TO anon, authenticated WITH CHECK (source_bytes BETWEEN 1 AND 100000);
