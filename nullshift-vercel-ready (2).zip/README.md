# NULLSHIFT — تشفير Lua واستضافة خاصة للسكربتات

## التشغيل محلياً
```sh
npm i
npm run dev
```

## النشر على Vercel
1. ارفع ملف ZIP من خلال Vercel Drop وأنت مسجّل الدخول؛ ملفات المشروع موجودة في جذر الأرشيف.
2. سيستخدم Vercel إعداد `TanStack Start` في `vercel.json` وأمر البناء `npm run build`.
3. استخدم Node.js 24.x، كما هو محدد في `package.json`.
4. أضف المتغيرات التالية في Vercel Environment Variables:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_PUBLISHABLE_KEY`
   - `SUPABASE_URL`
   - `SUPABASE_PUBLISHABLE_KEY`
5. طبّق ملفات SQL بالترتيب من `drizzle/migrations/` على قاعدة Supabase.
6. فعّل مزوّد البريد الإلكتروني في إعدادات Supabase Auth ثم اضغط Deploy.

السكربتات المنشورة خاصة بالحساب الذي أنشأها. واجهة المتصفح ترسل جلسة Supabase إلى الخادم، وسياسة RLS تقصر القراءة والكتابة على `owner_id`. طلبات `/raw/<id>` تحتاج ترويسة `Authorization: Bearer …` صالحة؛ لا توجد روابط عامة أو loadstrings مجهولة. الملفات القديمة التي ليس لها مالك تبقى في قاعدة البيانات لكنها لا تظهر للمستخدمين حتى يعيّن مسؤول قاعدة البيانات مالكاً لها.
